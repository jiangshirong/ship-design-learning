extends "res://modules/review/view/module11_ship.gd"
var revision_ink:Control
func _ready()->void:
 super._ready()
 revision_ink=preload("res://modules/review/view/revision9p_overlay.gd").new();revision_ink.view=self;add_child(revision_ink);revision_ink.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func apply(value:Dictionary,lang:String,evaluation:Dictionary={})->void:
 super.apply(value,lang,evaluation)
 if is_instance_valid(revision_ink):revision_ink.queue_redraw()
func anchor()->Vector2:
 if not is_instance_valid(revision_ink):return super.anchor()
 return Vector2(size.x*.5,185)
func obstacles()->Array:
 return [Rect2(24,116,size.x-48,270),Rect2(size.x*.12,size.y*.40,size.x*.76,size.y*.28)]
