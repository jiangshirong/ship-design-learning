extends Control
signal changed
signal navigated
signal field_created(field:TextEdit)
signal animation_requested(id:String)
signal topic_requested(id:String)
var topics:Array=JSON.parse_string(FileAccess.get_file_as_string("res://modules/review/content/topics.json"))
var topic_selected:=""
var topic_button:Button
var tree_items:Dictionary={}
var rebuilding:=false
const Text=preload("res://modules/review/view/notation_text.gd")
const Icons=preload("res://modules/review/view/review_icons.gd")
var store=preload("res://modules/review/core/reading_store.gd").new()
var entries:Array=[]
var filtered:Array[int]=[]
var index:=0
var revealed:=false
var exercise:=""
var listing:Tree
var panel:PanelContainer
var scroll:ScrollContainer
var column:VBoxContainer
var heading:Label
var question
var translation
var details:VBoxContainer
var notice:Label
var reveal_button:Button
var known_button:Button
var review_button:Button
var animation_button:Button
var example_button:Button
var variant_button:Button
var original_button:Button
var previous_button:Button
var next_button:Button
var footer:VBoxContainer
var formula_panels:Array=[]
var words
var nav_button:Button
var nav_open:=true
var answer_panel:PanelContainer
var answer_scroll:ScrollContainer
var action_row:HBoxContainer
var page_title:Label
func _ready()->void:
	entries=JSON.parse_string(FileAccess.get_file_as_string("res://modules/review/content/reading.json"));store.read_file()
	listing=Tree.new();listing.hide_root=true;listing.columns=2;listing.set_column_expand(1,false);listing.set_column_custom_minimum_width(1,40);listing.add_theme_font_size_override("font_size",19);listing.add_theme_constant_override("v_separation",10);add_child(listing)
	listing.add_theme_stylebox_override("panel",get_parent().style("122735"))
	listing.add_theme_stylebox_override("selected",get_parent().style("2b5061"));listing.add_theme_stylebox_override("selected_focus",get_parent().style("2b5061"))
	listing.add_theme_color_override("font_color",Color("dce7ee"));listing.add_theme_constant_override("outline_size",0)
	listing.item_selected.connect(tree_selected)
	listing.item_collapsed.connect(func(item:TreeItem):
		if not rebuilding:
			var id:String=str(item.get_metadata(0))
			if id.begins_with("topic:"):store.data.expanded[id.substr(6)]=not item.collapsed;save())
	panel=PanelContainer.new();panel.add_theme_stylebox_override("panel",StyleBoxEmpty.new());add_child(panel)
	scroll=ScrollContainer.new();scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;panel.add_child(scroll)
	column=VBoxContainer.new();column.size_flags_horizontal=Control.SIZE_EXPAND_FILL;column.add_theme_constant_override("separation",12);scroll.add_child(column)
	heading=Label.new();heading.add_theme_font_size_override("font_size",22);column.add_child(heading)
	question=make_text(column,32)
	translation=make_text(column,23);translation.hide()
	answer_panel=PanelContainer.new();answer_panel.add_theme_stylebox_override("panel",get_parent().style("1a3543"));add_child(answer_panel)
	answer_scroll=ScrollContainer.new();answer_scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;answer_panel.add_child(answer_scroll)
	details=VBoxContainer.new();details.size_flags_horizontal=SIZE_EXPAND_FILL;details.add_theme_constant_override("separation",23);answer_scroll.add_child(details)
	notice=Label.new();notice.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;notice.add_theme_font_size_override("font_size",17);column.add_child(notice)
	footer=VBoxContainer.new();footer.add_theme_constant_override("separation",8);add_child(footer)
	var row:=HBoxContainer.new();row.add_theme_constant_override("separation",8);footer.add_child(row)
	previous_button=button(row,"上一题 · Q",func():move(-1));next_button=button(row,"下一题 · E",func():move(1))
	reveal_button=button(row,"揭晓 · F",reveal);known_button=button(row,"会了",func():mark("known"));review_button=button(row,"稍后再看",func():mark("review"))
	known_button.icon=Icons.icon("known");review_button.icon=Icons.icon("review")
	var more:=HBoxContainer.new();more.add_theme_constant_override("separation",8);footer.add_child(more)
	animation_button=button(more,"看动画 · V",func():animation_requested.emit(entries[index].id))
	topic_button=button(more,"学习专题",func():topic_requested.emit(topic_selected));topic_button.hide()
	example_button=button(more,"计算示例",func():open_exercise("example"));variant_button=button(more,"练变式",func():open_exercise("variant"));original_button=button(more,"回原题",func():select_question(index))
	page_title=Label.new();page_title.text="题目";page_title.position=Vector2(32,24);page_title.add_theme_font_size_override("font_size",22);add_child(page_title);page_title.hide()
	nav_button=Button.new();add_child(nav_button);nav_button.hide()
	nav_button.icon=Icons.icon("sidebar");nav_button.tooltip_text="题目导航"
	nav_button.toggle_mode=true
	heading.reparent(self)
	for b in [previous_button,next_button,reveal_button,animation_button,topic_button]:b.reparent(self)
	action_row=HBoxContainer.new();action_row.add_theme_constant_override("separation",12);add_child(action_row)
	for b in [known_button,review_button,example_button,variant_button,original_button]:b.reparent(action_row)
	footer.hide()
	move_child(listing,get_child_count()-1)
	resized.connect(arrange)
	for i in entries.size():
		if entries[i].id==store.data.selected:index=i
	words=preload("res://modules/review/view/reading_words.gd").new();words.page=self;add_child(words)
	rebuild_filter();refresh();arrange()
func button(parent:Node,text:String,call:Callable)->Button:
	var b:=Button.new();b.text=text;b.custom_minimum_size.y=44;parent.add_child(b);b.pressed.connect(call);return b
func make_text(parent:Node,font_size:int=23):
	var t=Text.new();t.add_theme_font_size_override("font_size",font_size);parent.add_child(t);field_created.emit(t);return t
func add_text(value:String,size_:int=23):
	var t=make_text(details,size_);t.set_content(value);return t
func arrange()->void:
	if not nav_button:return
	var margin:float=maxf(64,(size.x-990)*.5)
	var nav_width:float=clampf(size.x*.25,280,360)
	var answer_left:float=32+nav_width+16 if nav_open else 0
	var right_margin:float=32 if nav_open else margin
	if nav_open:margin=answer_left+24
	var split:float=.50 if size.y<800 else .54
	question.add_theme_font_size_override("font_size",28 if size.y<800 else 32)
	details.add_theme_constant_override("separation",10 if size.y<800 else 23)
	nav_open=true;nav_button.hide()
	listing.position=Vector2(32,154);listing.size=Vector2(nav_width,size.y-240);listing.visible=nav_open
	heading.position=Vector2(margin if nav_open else 230,100);heading.size=Vector2(size.x-heading.position.x-190,40)
	panel.position=Vector2(margin,165);panel.size=Vector2(size.x-margin-right_margin,(size.y*split-185) if revealed else size.y-305)
	answer_panel.visible=revealed and topic_selected.is_empty() and index>=0
	answer_panel.position=Vector2(answer_left,size.y*split);answer_panel.size=Vector2(size.x-answer_left,size.y*(1-split)-125)
	var box:StyleBoxFlat=get_parent().style("1a3543");box.content_margin_left=margin-answer_left;box.content_margin_right=right_margin;box.content_margin_top=14 if size.y<800 else 26;answer_panel.add_theme_stylebox_override("panel",box)
	action_row.position=Vector2(margin,size.y-112);action_row.size=Vector2(size.x-margin-right_margin,48)
	known_button.visible=revealed;review_button.visible=revealed
	previous_button.position=Vector2(32,size.y-60);next_button.position=Vector2(size.x-172,size.y-60)
	reveal_button.visible=not revealed and topic_selected.is_empty() and index>=0;reveal_button.position=Vector2((margin+size.x-right_margin)*.5-100,size.y-128);reveal_button.size=Vector2(200,48)
	animation_button.position=Vector2(size.x-172,92);animation_button.size=Vector2(140,48)
	topic_button.position=Vector2(size.x*.5-110,size.y-160)
func current_question()->String:
	if index<0:return ""
	return entries[index].question_ru if exercise.is_empty() else entries[index].calculation[exercise].question_ru
func current_answer()->String:
	return entries[index].answer.ru if index>=0 and revealed and exercise.is_empty() else ""
func tree_selected()->void:
	if rebuilding:return
	var item:=listing.get_selected()
	if not item:return
	var id:String=str(item.get_metadata(0))
	if id.begins_with("topic:"):
		topic_selected=id.substr(6);refresh();scroll.scroll_vertical=0;return
	for i in entries.size():
		if entries[i].id==id:select_question(i);return
func rebuild_filter()->void:
	rebuilding=true;filtered.clear();listing.clear();tree_items.clear()
	var root:=listing.create_item()
	for topic in topics:
		var group:=listing.create_item(root);group.set_text(0,topic.title.zh);group.set_expand_right(0,true);group.set_metadata(0,"topic:"+topic.id)
		group.collapsed=not store.data.get("expanded",{}).get(topic.id,topic.id==entries[index].topic if index>=0 else false)
		for qid in topic.questions:
			for i in entries.size():
				if entries[i].id!=qid:continue
				var state:String=store.data.marks.get(qid,"")
				filtered.append(i)
				var item:=listing.create_item(group);item.set_metadata(0,qid)
				item.set_text(0," / ".join(entries[i].sources))
				item.set_icon(1,Icons.icon(state));item.set_icon_max_width(1,24)
				item.set_text_alignment(1,HORIZONTAL_ALIGNMENT_CENTER);item.set_selectable(1,false)
				item.set_tooltip_text(1,{"known":"会了","review":"稍后再看","":"未标记"}[state])
				tree_items[qid]=item
	if index not in filtered:index=filtered[0] if not filtered.is_empty() else -1
	if index>=0:tree_items[entries[index].id].select(0)
	rebuilding=false
func sync_selection()->void:
	if index<0 or not tree_items.has(entries[index].id):return
	rebuilding=true;var item:TreeItem=tree_items[entries[index].id];item.get_parent().collapsed=false;item.select(0);listing.ensure_cursor_is_visible();rebuilding=false
func save()->void:
	if index>=0:store.data.selected=entries[index].id
	if not store.write_file() and not store.blocked:notice.text="复习进度未能保存。"
func select_question(i:int)->void:
	navigated.emit();topic_selected="";index=i;exercise="";revealed=false;words.cursor=0;save();refresh();scroll.scroll_vertical=0
func move(direction:int)->void:
	if filtered.is_empty():return
	select_question(filtered[posmod(filtered.find(index)+direction,filtered.size())])
func mark(state:String)->void:
	if index<0 or not revealed:return
	store.data.marks[entries[index].id]=state;var before:=index;rebuild_filter()
	if index!=before:select_question(index)
	else:save();refresh()
func open_exercise(kind:String)->void:
	if index<0:return
	navigated.emit();exercise=kind;revealed=false;words.cursor=0;refresh();scroll.scroll_vertical=0
func reveal()->void:
	if index<0 or not topic_selected.is_empty():return
	revealed=not revealed;answer_scroll.scroll_vertical=0;refresh()
func refresh()->void:
	arrange.call_deferred()
	if words:words.schedule()
	changed.emit()
	for child in details.get_children():child.hide();child.queue_free()
	formula_panels.clear();details.visible=revealed and index>=0 and topic_selected.is_empty()
	var valid:=index>=0 and topic_selected.is_empty()
	translation.visible=valid and revealed
	question.visible=valid;reveal_button.disabled=not valid or revealed
	known_button.disabled=not valid or not revealed;review_button.disabled=not valid or not revealed
	animation_button.visible=valid;previous_button.disabled=not valid;next_button.disabled=not valid
	example_button.visible=valid and entries[index].has("calculation");variant_button.visible=example_button.visible
	original_button.visible=not exercise.is_empty()
	notice.text="复习存档损坏，原文件已保留，本次不覆盖。" if store.blocked else ("复习进度未能保存。" if not store.issue.is_empty() else "")
	topic_button.visible=not topic_selected.is_empty()
	if not topic_selected.is_empty():
		for topic in topics:
			if topic.id==topic_selected:
				heading.text=topic.title.zh;question.visible=true;question.set_content(topic.goal.zh)
		return
	if not valid:heading.text="待复习题目已完成，可切换到全部题目。";question.set_content("");return
	sync_selection()
	heading.text="%s · %s"%[" / ".join(entries[index].sources),{"":"原题","example":"计算示例","variant":"练习变式"}[exercise]]
	question.set_content(current_question())
	translation.set_content((entries[index].translation if exercise.is_empty() else entries[index].calculation[exercise].translation) if revealed else "")
	if not revealed:return
	if exercise.is_empty():
		var e:Dictionary=entries[index]
		add_text(e.answer.ru,29)
		var zh=add_text(e.answer.zh,23);zh.add_theme_color_override("font_readonly_color",Color("b7dcc6"))
		if e.has("formula_id"):add_formula(e.formula_id)
	else:
		var e:Dictionary=entries[index].calculation[exercise]
		add_text(e.steps[0],22);add_text(e.steps[1],22)
		add_formula(e.formula_id)
		add_text(e.steps[2],22);add_text(e.steps[3],22)
func add_formula(id:String)->void:
	var math=preload("res://modules/review/view/latex_panel.gd").new();details.add_child(math);math.set_beat(id,{},"zh");formula_panels.append(math)

