# Called inside the single visible Blender after raw FLIP and collision checks.
from mathutils.bvhtree import BVHTree
render_jobs=[(case,frame) for case in ['low','high','flare'] for frame in range(1,111)]
render_trees={}
for case in ['low','high','flare']:
 render_trees[case]=[]
 for path in sorted((OUT/case).glob('*-collider.json')):
  d=json.loads(path.read_text());v=np.array(d['vertices']);render_trees[case].append((BVHTree.FromPolygons(d['vertices'],d['faces'],all_triangles=True),v.min(0)-1.5,v.max(0)+1.5))
render_stats=[]
def filter_liquid_contact_faces():
 if not render_jobs:
  (ROOT/'qa/bow-fluid-render-surfaces.json').write_text(json.dumps(dict(method='Remove only liquid/solid contact interfaces facing into the colliding steel; raw physical caches remain unchanged.',frames=render_stats)),encoding='utf-8')
  return None
 case,frame=render_jobs.pop(0);src=OUT/case/f'{frame:04}.bwf';b=src.read_bytes();nv,ni=struct.unpack_from('<II',b,4)
 points=np.frombuffer(b,dtype='<f4',count=nv*3,offset=12).reshape(-1,3)
 normals=np.frombuffer(b,dtype='<f4',count=nv*3,offset=12+nv*12).reshape(-1,3)
 faces=np.frombuffer(b,dtype='<i4',count=ni,offset=12+nv*24).reshape(-1,3)
 centroids=points[faces].mean(axis=1);directions=normals[faces].mean(axis=1);lengths=np.linalg.norm(directions,axis=1);directions/=np.maximum(lengths[:,None],1e-6)
 discard=np.zeros(len(faces),bool)
 for tree,low,high in render_trees[case]:
  ids=np.flatnonzero(((centroids>low)&(centroids<high)).all(1))
  for i in ids:
   near,normal,index,distance=tree.find_nearest(Vector(centroids[i]))
   if distance<1.15*(93/RES) and normal.dot(Vector(directions[i]))<-.35:discard[i]=True
 kept=faces[~discard].astype('<i4')
 folder=OUT/case/'render';folder.mkdir(exist_ok=True)
 with (folder/f'{frame:04}.bwf').open('wb') as f:
  f.write(struct.pack('<4sII',b'BWF1',nv,kept.size));f.write(b[12:12+nv*24]);f.write(kept.tobytes())
 render_stats.append(dict(case=case,frame=frame,raw_triangles=len(faces),render_triangles=len(kept),contact_interfaces_removed=int(sum(discard))))
 (ROOT/'qa/bow-fluid-render-progress.json').write_text(json.dumps(dict(remaining=len(render_jobs),case=case,frame=frame)))
 return .01
bpy.app.timers.register(filter_liquid_contact_faces,first_interval=.5)
