extends CanvasLayer
# Click/release selects a dictionary identity; dragging remains native text selection.
var field:TextEdit
var tip
var save_unknown:Callable
var panel:PanelContainer
var text:RichTextLabel
var unknown:Button
var selected:Dictionary={}
var press:=Vector2.ZERO
var armed:=false
func _ready()->void:
	layer=31
	panel=PanelContainer.new();panel.theme=tip.panel.theme;add_child(panel)
	var style:=StyleBoxFlat.new();style.bg_color=Color("f2f6f9");style.set_corner_radius_all(7);style.set_content_margin_all(16);panel.add_theme_stylebox_override("panel",style)
	var column:=VBoxContainer.new();column.add_theme_constant_override("separation",12);panel.add_child(column)
	text=RichTextLabel.new();text.bbcode_enabled=true;text.fit_content=true;text.scroll_active=false;text.custom_minimum_size.x=300;text.add_theme_font_size_override("normal_font_size",22);text.add_theme_font_size_override("bold_font_size",22);text.add_theme_color_override("default_color",Color("203f54"));column.add_child(text)
	unknown=Button.new();unknown.text="不认识";unknown.custom_minimum_size.y=44;column.add_child(unknown)
	unknown.pressed.connect(func():
		if selected.is_empty():return
		if save_unknown.call(selected.id):dismiss()
		else:unknown.text="保存失败，请重试")
	field.gui_input.connect(on_field_input);panel.hide()
func dismiss()->void:panel.hide();selected={};armed=false
func _process(_dt:float)->void:
	if panel.visible and (not is_instance_valid(field) or not field.is_visible_in_tree()):dismiss()
	if panel.visible:tip.hide_tip()
func _input(event:InputEvent)->void:
	if panel.visible and event is InputEventMouseButton and event.pressed:
		if not panel.get_global_rect().has_point(event.position):dismiss()
func on_field_input(event:InputEvent)->void:
	if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
		if event.pressed:press=event.position;armed=true
		else:
			var choose:bool=armed and press.distance_to(event.position)<5.;armed=false
			if choose:pick(event.position)
	elif event is InputEventMouseMotion and armed and press.distance_to(event.position)>=5.:armed=false
func pick(point:Vector2)->void:
	var lc:=field.get_line_column_at_pos(Vector2i(point),false,false)
	if lc.y<0 or lc.x<0 or lc.x>=field.get_line(lc.y).length():return
	var offset:int=lc.x
	for line in lc.y:offset+=field.get_line(line).length()+1
	var candidates:Array=tip.glossary.spans(field.text).filter(func(s):return offset>=s.start and offset<s.end)
	if candidates.is_empty():return
	candidates.sort_custom(func(a,b):return a.end-a.start<b.end-b.start)
	var match_:Dictionary=candidates[0];selected=match_.entry
	text.text=tip.entry_text(field.text.substr(match_.start,match_.end-match_.start),selected)
	unknown.text="不认识";tip.hide_tip();panel.reset_size();panel.show()
	var bounds:=get_viewport().get_visible_rect().size
	panel.position=(field.global_position+point+Vector2(14,24)).clamp(Vector2(12,12),(bounds-panel.size-Vector2(12,12)).max(Vector2(12,12)))
