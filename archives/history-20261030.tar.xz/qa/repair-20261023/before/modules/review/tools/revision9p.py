"""9p additions, deduplicated source aliases and concise answer policy."""
import copy,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def bi(z,r):return {'zh':z,'ru':r}
ALIAS=dict(zip(range(1,17),['N01','N02','N03','N04','N05','N06','Q21','Q22','Q23','Q24','N10','Q25','N12','N13','N14','N15']))
ALIAS.update({20+i:f'M11Q{i+1:02}' for i in range(7)});ALIAS[35]='R9Q31'
# n, topic, accented original, translation, concise answer zh/ru, teaching scene.
ROWS=[
(17,'freeboard','Како́в результа́т расчёта, е́сли (Н – Т)min < (Н – Т)?','最小要求干舷小于实际干舷，计算结论是什么？','实际干舷足够。','Надво́дный борт доста́точен.','free_ok'),
(18,'freeboard','Како́в результа́т расчёта, е́сли (Н – Т)min = (Н – Т)?','最小要求干舷等于实际干舷，计算结论是什么？','恰好达到最小要求。','Ра́вен минима́льному.','free_equal'),
(19,'freeboard','Како́в результа́т расчёта, е́сли (Н – Т)min > (Н – Т)?','最小要求干舷大于实际干舷，计算结论是什么？','实际干舷不足。','Надво́дный борт недоста́точен.','free_short'),
(27,'propulsion','Что тако́е число́ Фру́да?','什么是弗劳德数？','反映惯性力与重力关系的无量纲数。','Показа́тель отноше́ния сил ине́рции и тя́жести.','froude'),
(28,'propulsion','Каки́е режи́мы движе́ния су́дна соотве́тствуют чи́слам Фру́да Fr < 1, 1 < Fr < 3 и Fr > 3?','Fr小于1、介于1和3、大于3分别对应哪些运动状态？','排水、过渡、滑行状态。','Водоизмеща́ющий, перехо́дный, глисси́рование.','regimes'),
(29,'propulsion','Что тако́е глисси́рование?','什么是滑行？','水的动升力支撑船体。','Ко́рпус подде́рживает подъёмная си́ла воды́.','planing'),
(30,'propulsion','Что тако́е буксиро́вочная мо́щность EPS?','什么是拖曳功率EPS？','克服船舶阻力的功率。','Мо́щность для преодоле́ния сопротивле́ния.','tow'),
(31,'propulsion','Как определя́ется тре́буемая мо́щность гла́вного дви́гателя N?','如何确定所需主机功率N？','拖曳功率除以总推进系数。','Де́лим EPS на η.','engine'),
(32,'propulsion','Чем отлича́ется мо́щность гла́вного дви́гателя от буксиро́вочной мо́щности?','主机功率与拖曳功率有什么区别？','主机功率还包含推进与传递损失。','Мо́щность дви́гателя учитыва́ет поте́ри.','loss'),
(33,'propulsion','Что учитыва́ет о́бщий пропульси́вный коэффицие́нт η?','总推进系数η考虑什么？','螺旋桨、轴系损失及船体相互作用。','Винт, валопрово́д и влия́ние ко́рпуса.','components'),
(34,'propulsion','Что тако́е о́бщий пропульси́вный коэффицие́нт η?','什么是总推进系数η？','拖曳功率与主机功率之比。','Отноше́ние EPS к N.','eta'),
(36,'propulsion','Почему́ у та́нкеров пропульси́вный коэффицие́нт ча́сто вы́ше, чем у сухогру́зов?','为什么油船的推进系数往往高于干货船？','通常是船体与螺旋桨的匹配更有利。','Благоприя́тнее взаимоде́йствие ко́рпуса и винта́.','wake'),
(37,'arrangement','Име́ется чертёж о́бщего расположе́ния «план ве́рхней па́лубы». Мо́жно ли по э́тому чертежу́ определи́ть, име́ется ли у су́дна надстро́йки?','已有总布置图中的上甲板平面图，能否判断船上是否有上层建筑？','可以，从其围壁与轮廓判断。','Да, по ко́нтурам сте́нок.','plan'),
(38,'arrangement','Для чего́ при проекти́ровании о́бщего расположе́ния су́дна необходи́мо знать коли́чество чле́нов экипа́жа?','设计总布置时为什么需要知道船员人数？','确定舱室、储备和救生设备。','Для помеще́ний, запа́сов и спаса́тельных средств.','crew'),
(39,'arrangement','Почему́ ходова́я (рулева́я) ру́бка располага́ется на са́мом ве́рхнем я́русе надстро́йки?','为什么驾驶室位于上层建筑最高层？','保证视野。','Для хоро́шего обзо́ра.','bridge'),
(40,'arrangement','Чем отлича́ется надстро́йка от ру́бки?','上层建筑与甲板室有什么区别？','上层建筑延伸至舷侧或接近舷侧，甲板室更内缩。','Надстро́йка дохо́дит до борто́в и́ли бли́зко к ним; ру́бка — нет.','width'),
(41,'arrangement','Как называ́ется носова́я надстро́йка су́дна?','船艏的上层建筑叫什么？','艏楼。','Бак.','forecastle'),
]
SHORT={
'Q03':('草图设计阶段。','Эски́зный прое́кт.'),
'N14':('满载状态。','По́лной нагру́зке.'),
'N15':('封闭上层建筑增加储备浮力。','Бо́льше запа́с плаву́чести.'),
'Q05':('不行，母型尺度应接近。','Нет. Ну́жен бли́зкий разме́р.'),
'Q21':('横摇过于急促。','Сли́шком ре́зкая ка́чка.'),
'Q18':('稳性消失角通常更大。','У́гол зака́та обы́чно бо́льше.'),
'Q19':('最大力臂通常更小。','Ма́ксимальное плечо́ обы́чно ме́ньше.'),
'Q20':('若初稳性高减小，周期更长。','Пери́од бо́льше при ме́ньшей метацентри́ческой высоте́.'),
'N02':('可以比较不同尺度的船。','Для сравне́ния судо́в ра́зных разме́ров.'),
'N03':('可能初稳性不足。','Возмо́жна недоста́точная осто́йчивость.'),
'N04':('可能横摇急促，取决于船型和载况。','Возмо́жна ре́зкая ка́чка.'),
'M11Q02':('减小兴波阻力。','Уме́ньшить волново́е сопротивле́ние.'),
'M11Q06':('减少甲板上浪与溅水。','Уме́ньшить залива́ние и забры́згивание па́лубы.'),
'M11Q03':('适度U形，减小波浪中的附加阻力。','Уме́ренно U-обра́зную: уме́ньшить дополни́тельное сопротивле́ние на волне́нии.'),
}
STEPS={
'froude':[('先固定特征尺度，比较航速与重力效应。','Сравни́м ско́рость и влия́ние тя́жести.',0,[]),('按船长定义Fr；按排水体积定义的Fr数值不同。','Число́ Фру́да зави́сит от вы́бора длины́.',1,[r'Fr_L=\frac{v}{\sqrt{gL}}',r'Fr_{\nabla}=\frac{v}{\sqrt{g\sqrt[3]{\nabla}}}'])],
'regimes':[('排水状态主要由浮力支撑。','Ко́рпус подде́рживает си́ла плаву́чести.',0,[r'Fr_{\nabla}<1']),('过渡状态中动升力作用增强。','В перехо́дном режи́ме растёт подъёмная си́ла.',.5,[r'1<Fr_{\nabla}<3']),('滑行状态主要靠水的动升力；这里的1和3按体积Fr解释。','При глисси́ровании ко́рпус подде́рживает подъёмная си́ла воды́.',1,[r'Fr_{\nabla}>3'])],
'planing':[('先看浮力，再看运动产生的动升力。','Снача́ла си́ла плаву́чести, зате́м подъёмная си́ла.',0,[]),('动升力支撑后，船体抬升、浸水部分减少。','Подъёмная си́ла поднима́ет ко́рпус.',1,[])],
 'tow':[('阻力与航行方向相反。','Сопротивле́ние напра́влено про́тив движе́ния.',0,[]),('拖曳功率等于阻力乘以航速。','Умножа́ем сопротивле́ние на ско́рость.',1,[r'EPS=R_Tv',r'\mathrm{kN}\cdot\frac{\mathrm m}{\mathrm s}=\mathrm{kW}'])],
'engine':[('有效功率只用于克服阻力；主机还要承担损失。','Мо́щность дви́гателя учитыва́ет поте́ри.',0,[]),('因此用拖曳功率除以总推进系数。','Де́лим EPS на η.',1,[r'N=\frac{EPS}{\eta}'])],
'loss':[('从主机到轴系、螺旋桨，再到有效功率。','Дви́гатель, валопрово́д, винт и поле́зная мо́щность.',0,[]),('推进链存在损失，因此两种功率不同。','В э́той це́пи есть поте́ри.',1,[r'\eta=\frac{EPS}{N}'])],
'components':[('轴系与螺旋桨都有损失。','Валопрово́д и винт име́ют поте́ри.',.4,[]),('总推进系数还包含船体与螺旋桨的相互作用。','Ва́жно и влия́ние ко́рпуса на винт.',1,[])],
'eta':[('比较有效功率与主机功率。','Сравни́м EPS и N.',0,[]),('有效功率除以主机功率，得到总推进系数。','Де́лим EPS на N.',1,[r'\eta=\frac{EPS}{N}'])],
'wake':[('船艉来流影响螺旋桨工作。','Пото́к за кормо́й влия́ет на винт.',0,[]),('油船可能具有更有利的匹配；不是所有油船都必然更高。','У та́нкера взаимоде́йствие мо́жет быть благоприя́тнее.',1,[])],
'plan':[('上甲板平面图显示围壁在甲板上的轮廓。','План па́лубы пока́зывает ко́нтуры сте́нок.',0,[]),('把图上的围壁与船上的上层建筑对应。','Сравни́м ко́нтуры на пла́не и надстро́йку.',1,[])],
'crew':[('先确定船员人数，再安排居住空间。','Число́ чле́нов экипа́жа определя́ет помеще́ния.',0,[]),('人数还影响淡水、食品与救生设备。','От числа́ люде́й зави́сят запа́сы и спаса́тельные сре́дства.',1,[])],
'bridge':[('低处的驾驶室视线会被甲板设施遮挡。','На ни́жнем я́русе обзо́р ограни́чен.',0,[]),('驾驶室设在最高层，获得较好的视野。','На ве́рхнем я́русе обзо́р лу́чше.',1,[])],
'width':[('先看延伸至舷侧的上层建筑。','Надстро́йка дохо́дит до борто́в.',0,[]),('再看围壁明显内缩的甲板室。','Сте́нки ру́бки не дохо́дят до борто́в.',1,[r'd\leq0.04B'])],
'forecastle':[('指出船艏的上层建筑。','Носова́я надстро́йка — бак.',0,[]),('与后续干舷专题中的艏楼对应。','Э́то тот же бак, что в те́ме надво́дного бо́рта.',1,[])],
}
def apply(courses,formulas,bank,readings):
 from yacht_lessons import STEPS as yacht_steps
 STEPS.update(yacht_steps)
 raw=json.loads((ROOT/'content/authoring/revision9p-original.json').read_text())
 for qid,(zh,ru) in SHORT.items():readings[qid]['answer']=bi(zh,ru)
 readings['Q03'].pop('condition',None)
 design=next(c for c in courses if c['id']=='design')
 stage=next(g for g in design['groups'] if g['id']=='Q03')
 for b in stage['beats']:
  if b['id']=='Q03:s1':b['words']=bi('本题对应草图设计阶段。','Эски́зный прое́кт.');b['text']=b['words']['zh']
  if b['id']=='Q03:s2':b['words']=bi('草图设计结束时，检查包括稳性在内的航海性能要求。','Эски́зный прое́кт: прове́рка осто́йчивости.');b['text']=b['words']['zh']
 readings['M11Q03']['condition']=bi('波浪中的阻力，不等于静水中的兴波阻力。','Сопротивле́ние на волне́нии — не то же, что волново́е сопротивле́ние.')
 for id,title,goal in [('propulsion','快速性与推进','在游艇上看懂抬艏与滑行，再沿主机、轴系到螺旋桨理解功率。'),('arrangement','总布置与船舶建筑','把甲板图、舱室用途与实际船上位置对应。')]:
  initial=dict(topic=id,qid='R9Q27' if id=='propulsion' else 'R9Q37',phase='revision',scene='overview',p=0.,draft=10.88,lines=0.)
  if id=='propulsion':initial['draft']=.72
  b=dict(id='R9:'+id+':foundation_end',words=bi(goal,'Рассмо́трим ско́рость и мо́щность.' if id=='propulsion' else 'Рассмо́трим о́бщее расположе́ние.'),start_params=initial.copy(),anchor='ship',camera='overview')
  courses.append(dict(id=id,title=bi(title,'Хо́дкость и мо́щность' if id=='propulsion' else 'О́бщее расположе́ние'),goal=b['words'],initial=initial,foundation_end=b['id'],questions=[],question_targets={},characters_per_second=25,groups=[dict(id='R9:'+id+':foundation',title=bi('目标','Цель'),beats=[b])]))
 for n,topic,ru,zh,azh,aru,scene in ROWS:
  qid=f'R9Q{n:02}';r=dict(id=qid,number=n,question_ru=ru,translation=zh,answer=bi(azh,aru),sources=[f'9p-{n}'],source=dict(question='9p-晚上发的/Проверочная работа 2. Вопросы для подготовки.docx',paragraph=raw[n-1]))
  if n==36:r['condition']=bi('这是常见匹配趋势，不是由“油船”这一名称保证的。','Результа́т зави́сит от ко́рпуса и винта́.')
  if n==40:r['condition']=bi('两侧围壁距舷侧不超过0.04B的接近全宽建筑可计为上层建筑。','Учитыва́ется шири́на.')
  readings[qid]=r;bank.append(dict(id=qid,number=n,title_zh=zh,question_original=raw[n-1],question_ru=ru,sources=r['sources']))
  c=next(c for c in courses if c['id']==topic);c['questions'].append(qid)
  rows=STEPS.get(scene,[(f'先比较实际干舷与最小要求。','Сравни́м надво́дный борт с минима́льным.',0,[]),(azh,aru,1,[{'free_ok':r'(H-T)_{\min}<H-T','free_equal':r'(H-T)_{\min}=H-T','free_short':r'(H-T)_{\min}>H-T'}[scene]])] if scene.startswith('free_') else [])
  beats=[]
  for j,(z,u,p,tex) in enumerate(rows):
   state={**c['initial'],'qid':qid,'scene':scene,'p':0.,'phase':'revision' if topic!='freeboard' else 'freeboard','draft':8.+p*2.,'superstructure':0.,'forecastle':0.,'sheer':0.}
   if topic=='propulsion':
    state['p']=rows[j-1][2] if j>0 else (0. if scene!='wake' else 1.)
    state['draft']=.72
   b=dict(id=f'R9:{qid}:{j}',words=bi(z,u),start_params=state,anchor='ship',camera='overview',action=dict(params={'p':p},duration=3.5 if topic=='propulsion' else 2.5))
   if 'condition' in r and j==len(rows)-1:b['condition']=r['condition']
   beats.append(b)
   if tex:formulas[b['id']]={lang:[dict(tex=t,linear=t) for t in tex] for lang in ['zh','ru']}
  beats.append(dict(id=f'R9:{qid}:answer',words=r['answer'],start_params={**state,'p':1.},anchor='ship',recap=bi(zh+'\n'+azh,ru+'\n'+aru)))
  titles=['干舷足够','干舷临界','干舷不足','弗劳德数','运动状态','滑行','拖曳功率','主机功率','功率损失','推进链','推进系数','船体与螺旋桨','甲板平面图','船员人数','驾驶室视野','上层建筑与甲板室','艏楼名称']
  russian=['Борт доста́точен','Мини́мум','Борт недоста́точен','Число́ Фру́да','Режи́мы','Глисси́рование','EPS','Мо́щность N','Поте́ри','Цепь переда́чи','Коэффицие́нт η','Ко́рпус и винт','План па́лубы','Экипа́ж','Обзо́р','Надстро́йка и ру́бка','Бак']
  k=[row[0] for row in ROWS].index(n)
  group=dict(id=qid,title=bi(titles[k],russian[k]),beats=beats)
  if topic=='freeboard':
   idx=next(i for i,g in enumerate(c['groups']) if g['id']=='N15');c['groups'].insert(idx,group)
  else:c['groups'].append(group)
  c['question_targets'][qid]=beats[0]['id']
 for n,qid in ALIAS.items():
  b=next(q for q in bank if q['id']==qid);b['sources'].append(f'9p-{n}');readings[qid]['sources']=b['sources']
  readings[qid].setdefault('source_variants',[]).append(dict(source=f'9p-{n}',original=raw[n-1]))
 # Sync concise answers to all recap beats and old lessons, without changing IDs.
 for c in courses:
  for g in c['groups']:
   for b in g['beats']:
    b.setdefault('text',b['words']['zh'])
    qid=b.get('start_params',{}).get('qid',g['id'])
    if qid in readings and (b['id'].endswith(':answer') or 'recap' in b):
     r=readings[qid];b['words']=copy.deepcopy(r['answer']);b['text']=r['answer']['zh'];b['recap']=bi(r['translation']+'\n'+r['answer']['zh'],r['question_ru']+'\n'+r['answer']['ru'])
  for qid in c['questions']:
   q=next(q for q in bank if q['id']==qid);q.update(topic=c['id'],target=c['question_targets'][qid]);readings[qid].update(topic=c['id'],target=q['target'])
 # Place new knowledge between hull-form and stability; arrangement follows freeboard.
 c=courses.pop(next(i for i,c in enumerate(courses) if c['id']=='propulsion'));courses.insert(next(i for i,c in enumerate(courses) if c['id']=='hullform')+1,c)
 # Reading follows the animation's concept order (not file order).
 for c in courses:
  order=[g['id'] for g in c['groups'] if g['id'] in c['questions']];c['questions']=list(dict.fromkeys(order+c['questions']))

def vocabulary():
 p=ROOT/'content/glossary.json';entries=json.loads(p.read_text());norm=lambda s:s.lower().replace('\u0301','').replace('ё','е')
 rows='''число́ Фру́да|число фруда;числам фруда;числа фруда|弗劳德数
глисси́рование|глиссирование;глиссировании|滑行
буксиро́вочная мо́щность|буксировочной мощности;буксировочная мощность|拖曳功率
пропульси́вный коэффицие́нт|пропульсивный коэффициент;пропульсивного коэффициента|推进系数
дви́гатель|двигателя;двигатель|发动机
валопрово́д|валопровод;валопровода|轴系
подъёмная си́ла|подъёмная сила;подъемная сила;подъёмная сила воды|动升力
поте́ря|потери;потерь;потеря|损失
о́бщее расположе́ние|общего расположения;общее расположение|总布置
я́рус|ярусе;ярус|层
обзо́р|обзора;обзор|视野
ко́нтур|контурам;контур;контуры|轮廓
ру́бка|рубка;рубки;рубке|甲板室；驾驶室（视上下文）
экипа́ж|экипажа;экипаж|船员
коли́чество|количество;количества|数量
водоизмеща́ющий|водоизмещающий|排水的
перехо́дный|переходный|过渡的
подде́рживать|поддерживает;поддерживать|支撑
благоприя́тный|благоприятнее;благоприятный|有利的
ходова́я ру́бка|ходовая рубка;ходовой рубки|驾驶室
надстро́йка|надстройки;надстройка|上层建筑
доста́точный|достаточен;достаточный|足够的
недоста́точный|недостаточен;недостаточный|不足的
ве́рхний|верхней;верхнем;верхний|上方的
винт|винт;винта|螺旋桨
гла́вный|главного;главный|主要的
движе́ние|движения;движение|运动
доходи́ть|доходит;доходить|延伸至
знать|знать|知道
име́ться|имеется;иметься|具有；存在
минима́льный|минимальному;минимальный|最小的
определя́ться|определяется;определяться|被确定
преодоле́ние|преодоления;преодоление|克服
ра́вный|равен;равный|相等的
располага́ться|располагается;располагаться|位于
режи́м|режимы;режим|状态；工况
результа́т|результат;результата|结果
рулево́й|рулевая;рулевой|操舵的；驾驶的
соотве́тствовать|соответствуют;соответствовать|对应
спаса́тельный|спасательных;спасательный|救生的
сре́дство|средств;средство|设备；手段
сте́нка|стенок;стенка|围壁
сухогру́з|сухогрузов;сухогруз|干货船
та́нкер|танкеров;танкер|油船；液货船
тре́буемый|требуемая;требуемый|所需的
ходово́й|ходовая;ходовой|航行的
хоро́ший|хорошего;хороший|良好的
чертёж|чертежу;чертёж;чертеж|图纸
член|членов;член|成员
дополни́тельный|дополнительное;дополнительный|附加的
ине́рция|инерции;инерция|惯性
тя́жесть|тяжести;тяжесть|重力'''
 for row in rows.splitlines():
  ru,als,zh=row.split('|');old=next((e for e in entries if norm(e['ru'])==norm(ru)),None)
  if old:old['aliases']=list(dict.fromkeys(old.get('aliases',[])+als.split(';')))
  else:entries.append(dict(id='r9_'+norm(ru).replace(' ','_'),ru=ru,zh=zh,meaning=zh,aliases=als.split(';'),study=True))
 from yacht_lessons import add_lookup
 add_lookup(entries)
 p.write_text(json.dumps(entries,ensure_ascii=False,indent=2),encoding='utf-8')
 from apply_glossary_review import apply
 apply()
