# 25题模块

由主工程 main.gd 管理入口与输入，module.gd 提供 open_reading、open_vocabulary、open_question_animation 和 exit_requested。不是独立应用。

全部运行资源使用 res://modules/review/，存档使用 user://review/。语音功能已移除；speech_bubble.gd 仅为文字对话框，无音频功能。

构建：在主工程 tools/latex/node_modules 已安装依赖的环境中设置 NODE_PATH，再运行本模块 tools/latex/build.cjs。课程数据生成脚本从课程根目录读取原始资料。stability_details.py 从主工程 assets/tanker_learning.glb 提取部件。无需旧工程目录。

qa 中早期文档与 JSON 为历史证据；本次合并结果以主工程 qa/2026-10-20-25题合并.md 为准。
