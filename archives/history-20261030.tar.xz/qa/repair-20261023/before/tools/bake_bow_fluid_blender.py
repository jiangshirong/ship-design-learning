"""Visible Blender FLIP liquid authoring and collision bake; standalone owned window."""
import bpy, bmesh, json, math, time, traceback, struct, os
from pathlib import Path
from mathutils import Vector, Quaternion
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
import hashlib
ASSET=ROOT/'modules/review/assets/module11_ship.glb'
ASSET_HASH=hashlib.sha256(ASSET.read_bytes()).hexdigest()
EXPECTED='1a8be93498f280776f0eaeb9f9d94537caa03d80163b58f9941cefffc0e1e1ff'
assert ASSET_HASH==EXPECTED,'Ship changed: require fresh source verification'
pause=ROOT/'qa/bow-fluid-paused.json'
if pause.exists():
 guard=json.loads(pause.read_text(encoding='utf-8'))
 if guard.get('source_sha256')==ASSET_HASH or guard.get('status')!='paused_for_hull_repair':
  raise RuntimeError('This geometry bake is paused by the user')
OUT=ROOT/'modules/review/assets/bow_fluid'/ASSET_HASH[:8];OUT.mkdir(parents=True,exist_ok=True)
CACHE=ROOT/('models/bow_fluid_cache_'+ASSET_HASH[:8]+'_all');CACHE.mkdir(parents=True,exist_ok=True)
STATUS=ROOT/'qa/bow-fluid-bake-status.json'
SCALE=.1;END=110;RES=88
cases=[c.strip() for c in os.environ.get('BOW_FLUID_CASES','low,high,flare').split(',') if c.strip()]
assert cases and all(c in ['low','high','flare'] for c in cases)
case_index=0;stage='setup';domain=None;settings=None;start=0;export_frame=1;records=[];stats=[];objects=[]

def status(**kw):
 value=dict(case=cases[min(case_index,len(cases)-1)],stage=stage,elapsed=round(time.time()-start,1),**kw)
 STATUS.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def mat(name,color):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
 bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Roughness'].default_value=.18;bs.inputs['Metallic'].default_value=.15
 return m

def cube(name,lo,hi):
 bpy.ops.mesh.primitive_cube_add(size=1,location=tuple((lo[i]+hi[i])*.5*SCALE for i in range(3)))
 o=bpy.context.object;o.name=name;o.dimensions=tuple((hi[i]-lo[i])*SCALE for i in range(3));bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o

def setup(case):
 global domain,settings,objects,start
 start=time.time();bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 scene=bpy.context.scene;scene.frame_start=1;scene.frame_end=END;scene.render.fps=24;scene.gravity=(0,0,-9.81*SCALE)
 # Import the exact visual ship and evaluate the same morphs used by Godot.
 bpy.ops.import_scene.gltf(filepath=str(ROOT/'modules/review/assets/module11_ship.glb'))
 for o in list(scene.objects):
  if o.type!='MESH':continue
  if o.data.shape_keys:
   o.data.shape_keys.animation_data_clear()
   for k in o.data.shape_keys.key_blocks:k.value=1. if (case=='high' and k.name=='Forecastle') or (case=='flare' and k.name=='Flare') else 0.
 scene.frame_set(1);bpy.context.view_layer.update()
 dg=bpy.context.evaluated_depsgraph_get()
 # Only sealed structural solids collide. Thin rails are smaller than this grid.
 colliders=[]
 for o in list(scene.objects):
  if o.type!='MESH':continue
  if not (o.name.startswith('Continuous') or (case=='high' and o.name.startswith('Forecastle tapered'))):
   bpy.data.objects.remove(o,do_unlink=True);continue
  evaluated=o.evaluated_get(dg);mesh=bpy.data.meshes.new_from_object(evaluated,depsgraph=dg)
  world=o.matrix_world.copy()
  for v in mesh.vertices:v.co=world@v.co
  bm=bmesh.new();bm.from_mesh(mesh)
  bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001)
  assert all(e.is_manifold for e in bm.edges),'Imported visual shell not watertight after welding'
  ret=bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=.0001,plane_co=(40,0,0),plane_no=(1,0,0),clear_inner=True)
  edges=[e for e in bm.edges if e.is_boundary];bmesh.ops.holes_fill(bm,edges=edges,sides=0)
  bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces))
  assert all(e.is_manifold for e in bm.edges),'Clipped collision hull has open/nonmanifold edges'
  bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free()
  for v in mesh.vertices:v.co*=SCALE
  collider=bpy.data.objects.new('Collision '+o.name,mesh);scene.collection.objects.link(collider);colliders.append(collider)
  bpy.data.objects.remove(o,do_unlink=True)
  mod=collider.modifiers.new('Liquid collision from actual ship','FLUID');mod.fluid_type='EFFECTOR';eff=mod.effector_settings;eff.effector_type='COLLISION';eff.surface_distance=.35;eff.subframes=2
  # Export exact collider topology for independent liquid readback.
  cv=np.array([list(v.co) for v in mesh.vertices],dtype=np.float32)/SCALE
  godot=np.stack([cv[:,0],cv[:,2]-8,-cv[:,1]],axis=1)
  cf=[list(p.vertices) for p in mesh.polygons]
  target=OUT/case;target.mkdir(exist_ok=True)
  (target/(str(len(colliders))+'-collider.json')).write_text(json.dumps(dict(vertices=godot.tolist(),faces=cf,watertight=True,bulb=0,source_sha256=ASSET_HASH)))
  collider.data.materials.clear();collider.data.materials.append(mat('Painted ship steel',(.21,.38,.40)))
 # Resting sea with an incident elevated water packet, both computed by FLIP.
 sea=cube('Initial sea', (42,-30,.3),(131,30,8.0))
 # Remove fluid initially inside the watertight hull, so the experiment starts dry.
 for c in colliders:
  boolean=sea.modifiers.new('Dry inside hull','BOOLEAN');boolean.operation='DIFFERENCE';boolean.solver='EXACT';boolean.object=c
  bpy.context.view_layer.objects.active=sea;bpy.ops.object.modifier_apply(modifier=boolean.name)
 flow=sea.modifiers.new('Initial resting water','FLUID');flow.fluid_type='FLOW';flow.flow_settings.flow_type='LIQUID';flow.flow_settings.flow_behavior='GEOMETRY';flow.flow_settings.surface_distance=0
 packet=cube('Incident water volume',(105,-29,8),(130,29,22))
 if case=='flare':packet.rotation_euler.z=math.radians(13)
 flow=packet.modifiers.new('Incoming liquid momentum','FLUID');flow.fluid_type='FLOW';f=flow.flow_settings;f.flow_type='LIQUID';f.flow_behavior='GEOMETRY';f.use_initial_velocity=True;f.velocity_coord=(-10*SCALE,-2*SCALE if case=='flare' else 0,0);f.surface_distance=0
 for o in [sea,packet]:o.hide_render=True;o.display_type='WIRE'
 domain=cube('FLIP wave — '+case,(40,-32,0),(133,32,29))
 mod=domain.modifiers.new('Actual liquid simulation','FLUID');mod.fluid_type='DOMAIN';settings=mod.domain_settings;settings.domain_type='LIQUID';settings.resolution_max=RES;settings.cache_type='ALL';settings.cache_frame_start=1;settings.cache_frame_end=END;settings.cache_directory=str(CACHE/case);settings.cache_data_format='UNI';settings.cache_mesh_format='BOBJECT';settings.use_mesh=True;settings.mesh_scale=2;settings.timesteps_min=2;settings.timesteps_max=8;settings.particle_number=2;settings.flip_ratio=.85
 domain.data.materials.append(mat('Computed FLIP water',(.025,.22,.29)))
 for area in bpy.context.window_manager.windows[0].screen.areas:
  if area.type=='VIEW_3D':
   s=area.spaces.active;s.clip_end=1000;s.shading.type='MATERIAL';s.region_3d.view_location=Vector((8,0,1));s.region_3d.view_distance=13;s.region_3d.view_rotation=Quaternion((.84,.42,-.16,-.28)).normalized()
 bpy.ops.object.select_all(action='DESELECT');domain.select_set(True);bpy.context.view_layer.objects.active=domain
 # Keep each setup independently inspectable, not just opaque playback data.
 bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'models'/('船艏液体碰撞-'+case+'.blend')))
 status(colliders=[dict(name=c.name,vertices=len(c.data.vertices),faces=len(c.data.polygons)) for c in colliders],resolution=RES,frames=END,gravity=list(scene.gravity),length_scale=SCALE)
 # Sequential dependency-graph stepping calculates FLIP with no cancelable modal bake.

def export_one(frame):
 bpy.context.scene.frame_set(frame);bpy.context.view_layer.update()
 evaluated=domain.evaluated_get(bpy.context.evaluated_depsgraph_get());mesh=evaluated.to_mesh();mesh.calc_loop_triangles()
 verts=np.empty(len(mesh.vertices)*3,dtype=np.float32);mesh.vertices.foreach_get('co',verts);verts=verts.reshape(-1,3)
 normals=np.empty_like(verts);mesh.vertices.foreach_get('normal',normals.ravel())
 m=np.array(domain.matrix_world,dtype=np.float32);verts=verts@m[:3,:3].T+m[:3,3];verts/=SCALE
 # Blender X/Y/Z -> Godot X/Z/-Y; sea level is world y=0 at draft=8.
 points=np.stack([verts[:,0],verts[:,2]-8,-verts[:,1]],axis=1).astype('<f4')
 n=np.stack([normals[:,0],normals[:,2],-normals[:,1]],axis=1).astype('<f4')
 indices=np.empty(len(mesh.loop_triangles)*3,dtype=np.int32);mesh.loop_triangles.foreach_get('vertices',indices)
 # Reflection of one axis: reverse winding for Godot's clockwise front faces.
 indices=indices.reshape(-1,3)[:,[0,2,1]].astype('<i4')
 file=OUT/cases[case_index]/f'{frame:04}.bwf';file.parent.mkdir(exist_ok=True)
 with file.open('wb') as f:f.write(struct.pack('<4sII',b'BWF1',len(points),indices.size));f.write(points.tobytes());f.write(n.tobytes());f.write(indices.tobytes())
 stats.append(dict(frame=frame,vertices=len(points),triangles=len(indices),min=points.min(axis=0).tolist() if len(points) else [],max=points.max(axis=0).tolist() if len(points) else []))
 evaluated.to_mesh_clear()

def tick():
 global stage,case_index,export_frame,stats
 try:
  inbox=ROOT/'qa/bow-fluid-blender-command.py'
  if inbox.exists():
   command=inbox.read_text(encoding='utf-8-sig');inbox.unlink();exec(command,globals())
  if stage=='setup':
   setup(cases[case_index]);stage='solve';return 1.0
  if stage=='solve':
   status()
   with bpy.context.temp_override(window=bpy.context.window_manager.windows[0]):
    outcome=bpy.ops.fluid.bake_all()
   assert 'FINISHED' in outcome,outcome
   assert (CACHE/cases[case_index]/'mesh'/f'fluid_mesh_{END:04}.bobj.gz').exists(),'Incomplete native liquid cache'
   stage='exporting';export_frame=1;stats=[];return .1
  if stage=='baking':
   count=len(list((CACHE/cases[case_index]/'mesh').glob('*')));status(mesh_files=count)
   if not settings.is_cache_baking_any and settings.has_cache_baked_data and settings.has_cache_baked_mesh and (CACHE/cases[case_index]/'mesh'/f'fluid_mesh_{END:04}.bobj.gz').exists():
    stage='exporting';export_frame=1;stats=[];bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath);return 1.
   if not settings.is_cache_baking_any and time.time()-start>15:
    status(retrying_interrupted_bake=True)
    bpy.context.view_layer.objects.active=domain;domain.select_set(True);bpy.ops.fluid.bake_all('INVOKE_DEFAULT')
   return 3.
  if stage=='exporting':
   export_one(export_frame);status(exported=export_frame)
   export_frame+=1
   if export_frame<=END:return .025
   record=dict(computation='Blender FLIP complete ALL cache bake with synchronous completion check',source_sha256=ASSET_HASH,cache_directory=str(CACHE/cases[case_index]),case=cases[case_index],fps=24,frames=END,resolution=RES,length_scale=SCALE,actual_collision=True,source='module11_ship.glb evaluated structural meshes',stats=stats)
   (OUT/cases[case_index]/'manifest.json').write_text(json.dumps(record),encoding='utf-8');records.append(record);case_index+=1
   if case_index<len(cases):stage='setup';return 2.
   stage='complete';(OUT/'manifest.json').write_text(json.dumps(dict(source_sha256=ASSET_HASH,cases=[c.strip() for c in os.environ.get('BOW_FLUID_CASES','low,high,flare').split(',') if c.strip()]
assert cases and all(c in ['low','high','flare'] for c in cases),fps=24,frames=END,resolution=RES,actual_collision=True)),encoding='utf-8');status();return None
 except Exception:
  stage='error';status(error=traceback.format_exc());return None
bpy.app.timers.register(tick,first_interval=3.)
