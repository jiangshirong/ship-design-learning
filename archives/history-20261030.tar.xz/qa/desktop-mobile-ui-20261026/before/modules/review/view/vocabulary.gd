extends Control
signal changed
const Schedule=preload("res://modules/review/core/review_schedule.gd")
var schedule:Dictionary={}
var scientific:=false
var session_total:=0
var clock_override:=-1.0
const LEVELS=["已掌握","认识","不熟","完全不会"]
var all_entries:Array=[]
var entries:Array=[]
var index:=0
var revealed:=false
var category:=""
var marks:Dictionary={}
var path:="user://review/vocabulary.json"
var blocked:=false
var menu:VBoxContainer
var card:Control
var counter:Label
var chinese:Label
var russian
var reveal_button:Button
var previous:Button
var next_button:Button
var filter:OptionButton
var grade_buttons:Array[Button]=[]
var notice:Label
var continue_button:Button
var grades:HBoxContainer
var outer:Control
var page_title:Label
func _ready()->void:
	if "--qa" in OS.get_cmdline_user_args():path="user://review/qa-vocabulary.json"
	all_entries=preload("res://modules/review/core/glossary.gd").new().study_entries()
	load_marks()
	var box:=StyleBoxFlat.new();box.bg_color=Color("162e3e");box.set_corner_radius_all(10)
	box.content_margin_left=36;box.content_margin_right=36;box.content_margin_top=28;box.content_margin_bottom=28;add_theme_stylebox_override("panel",box)
	outer=Control.new();add_child(outer);outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu=VBoxContainer.new();menu.add_theme_constant_override("separation",18);outer.add_child(menu)
	for kind in ["单词","词组"]:
		var b:=Button.new();b.text=kind;b.custom_minimum_size.y=64;menu.add_child(b);b.pressed.connect(open_category.bind(kind))
	card=VBoxContainer.new();card.add_theme_constant_override("separation",22);outer.add_child(card)
	var top:=HBoxContainer.new();card.add_child(top)
	counter=Label.new();counter.size_flags_horizontal=Control.SIZE_EXPAND_FILL;top.add_child(counter)
	filter=OptionButton.new();top.add_child(filter)
	for value in ["全部","未标记"]+LEVELS:filter.add_item(value)
	filter.item_selected.connect(func(_i):rebuild();index=0;revealed=false;refresh())
	russian=preload("res://modules/review/view/selectable_text.gd").new();russian.add_theme_font_size_override("font_size",48);card.add_child(russian)
	chinese=Label.new();chinese.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;chinese.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;chinese.add_theme_font_size_override("font_size",32);card.add_child(chinese)
	reveal_button=Button.new();reveal_button.custom_minimum_size.y=52;card.add_child(reveal_button);reveal_button.pressed.connect(reveal)
	grades=HBoxContainer.new();grades.add_theme_constant_override("separation",8);card.add_child(grades)
	for level in LEVELS:
		var b:=Button.new();b.text=str(LEVELS.find(level)+1)+" "+level;b.toggle_mode=true;b.size_flags_horizontal=Control.SIZE_EXPAND_FILL;b.custom_minimum_size.y=48;grades.add_child(b);grade_buttons.append(b);b.pressed.connect(mark.bind(level))
		var selected:=StyleBoxFlat.new();selected.bg_color=Color("46614f");selected.border_color=Color("ffcf7b");selected.set_border_width_all(2);selected.set_corner_radius_all(8)
		selected.content_margin_left=16;selected.content_margin_right=16;selected.content_margin_top=12;selected.content_margin_bottom=12
		b.add_theme_stylebox_override("pressed",selected);b.add_theme_stylebox_override("hover_pressed",selected)
		b.add_theme_color_override("font_pressed_color",Color("ffe0a5"));b.add_theme_color_override("font_hover_pressed_color",Color("ffe0a5"))
	var row:=HBoxContainer.new();row.add_theme_constant_override("separation",20);card.add_child(row)
	previous=Button.new();previous.text="上一项 · Q";previous.size_flags_horizontal=Control.SIZE_EXPAND_FILL;previous.custom_minimum_size.y=48;row.add_child(previous);previous.pressed.connect(func():move(-1))
	next_button=Button.new();next_button.text="下一项 · E";next_button.size_flags_horizontal=Control.SIZE_EXPAND_FILL;row.add_child(next_button);next_button.pressed.connect(func():move(1))
	notice=Label.new();notice.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;outer.add_child(notice)
	continue_button=Button.new();continue_button.text="继续复习";continue_button.custom_minimum_size.y=48;outer.add_child(continue_button);continue_button.pressed.connect(func():open_category(category))
	for n in [counter,filter,russian,chinese,reveal_button,grades,previous,next_button]:n.reparent(card)
	# Card is a logical group; child geometry is controlled by a plain Control.
	var group:=Control.new();outer.add_child(group)
	for n in card.get_children():n.reparent(group)
	card.hide();card.name="OldCard";card=group
	page_title=Label.new();page_title.text="科学复习";page_title.position=Vector2(32,24);outer.add_child(page_title)
	group.name="FocusCard"
	resized.connect(arrange);open_menu();arrange()
func kind(entry:Dictionary)->String:
	return "词组" if entry.ru.strip_edges().contains(" ") else "单词"
func open_menu()->void:
	category="";menu.show();card.hide();continue_button.hide();refresh_notice();arrange.call_deferred();changed.emit()
func now()->float:
	return clock_override if clock_override>=0 else Time.get_unix_time_from_system()
func needs_review(id:String)->bool:
	return not marks.has(id) or Schedule.due(id,schedule,now())
func open_category(value:String)->void:
	category=value;filter.select(0);index=0;revealed=false;rebuild();session_total=entries.size();menu.hide();card.show();filter.visible=not scientific;refresh()
func rebuild()->void:
	entries=[]
	for entry in all_entries:
		if kind(entry)!=category:continue
		if scientific and not needs_review(entry.id):continue
		var grade:String=marks.get(entry.id,"")
		if filter.selected==1 and not grade.is_empty():continue
		if filter.selected>=2 and grade!=LEVELS[filter.selected-2]:continue
		entries.append(entry)
	if scientific:
		var original_order:Dictionary={}
		for i in all_entries.size():original_order[all_entries[i].id]=i
		entries.sort_custom(func(a,b):
			if marks.has(a.id)!=marks.has(b.id):return not marks.has(a.id)
			var rank_a:int=LEVELS.find(marks.get(a.id,"完全不会"));var rank_b:int=LEVELS.find(marks.get(b.id,"完全不会"))
			return rank_a>rank_b if rank_a!=rank_b else original_order[a.id]<original_order[b.id])
		if entries.size()>20:entries.resize(20)
	index=clampi(index,0,maxi(0,entries.size()-1))
func refresh_notice()->void:
	notice.text="记录损坏，已保留原文件，本次不覆盖。" if blocked else ""
func refresh()->void:
	if category.is_empty():return
	var valid:=not entries.is_empty()
	continue_button.visible=scientific and not valid
	counter.text=category+"　%d / %d"%[index+1 if valid else 0,entries.size()]
	russian.set_content(entries[index].ru if valid else ("本轮复习完成" if scientific and session_total>0 else ("暂无到期词条" if scientific else "暂无符合条件的词条")))
	chinese.text=entries[index].zh if valid and revealed else ""
	reveal_button.text="隐藏中文 · 空格" if revealed else "显示中文 · 空格"
	for b in [reveal_button,previous,next_button]:b.disabled=not valid
	for i in grade_buttons.size():
		grade_buttons[i].disabled=not valid or blocked
		grade_buttons[i].set_pressed_no_signal(valid and marks.get(entries[index].id,"")==LEVELS[i])
		grade_buttons[i].text=str(i+1)+" "+LEVELS[i]+(" ✓" if grade_buttons[i].button_pressed else "")
	refresh_notice()
	if scientific and not valid and not blocked:
		var pending:=false
		for entry in all_entries:
			if kind(entry)==category and needs_review(entry.id):pending=true;break
		if pending:
			notice.text="还有待测词条，可以继续下一轮。";arrange.call_deferred();changed.emit();return
		var earliest:=-1.0
		for entry in all_entries:
			if kind(entry)==category and schedule.has(entry.id):
				var due_at:float=schedule[entry.id].due_at
				if earliest<0 or due_at<earliest:earliest=due_at
		if earliest>=0:
			var minutes:int=maxi(1,ceili((earliest-now())/60.0))
			notice.text="下次复习约在 %d 分钟后"%minutes if minutes<60 else ("下次复习约在 %d 小时后"%ceili(minutes/60.0) if minutes<1440 else "下次复习约在 %d 天后"%ceili(minutes/1440.0))
	arrange.call_deferred();changed.emit()
func reveal()->void:
	if category.is_empty() or entries.is_empty():return
	revealed=not revealed;refresh()
func move(direction:int)->void:
	if category.is_empty() or entries.is_empty():return
	if scientific:
		index=posmod(index+direction,entries.size());revealed=false;refresh();return
	var id:String=entries[index].id;var old_index:=index
	rebuild()
	var found:=-1
	for i in entries.size():
		if entries[i].id==id:found=i;break
	if not entries.is_empty():index=posmod(found+direction,entries.size()) if found>=0 else mini(old_index,entries.size()-1)
	revealed=false;refresh()
func mark(level:String)->void:
	if entries.is_empty() or blocked or not revealed:return
	var id:String=entries[index].id
	if not record_grade(id,level):refresh();notice.text="等级未能保存，请重试。";return
	if scientific:
		entries.remove_at(index);index=mini(index,maxi(0,entries.size()-1));revealed=false;refresh()
	else:move(1)
func record_grade(id:String,level:String)->bool:
	if blocked or id.is_empty() or level not in LEVELS:return false
	var old_marks:Dictionary=marks.duplicate(true);var old_schedule:Dictionary=schedule.duplicate(true)
	marks[id]=level;schedule[id]=Schedule.next_review(level,now())
	if not save_marks():
		marks=old_marks;schedule=old_schedule;return false
	return true
func load_marks()->void:
	if not FileAccess.file_exists(path):return
	var parser:=JSON.new()
	if parser.parse(FileAccess.get_file_as_string(path))!=OK:blocked=true;return
	var parsed=parser.data
	if not parsed is Dictionary or (parsed.get("version")!=1 and parsed.get("version")!=2) or not parsed.get("marks") is Dictionary:blocked=true;return
	for id in parsed.marks:
		if not id is String or parsed.marks[id] not in LEVELS:blocked=true;return
	if parsed.version==2 and not Schedule.valid(parsed.get("schedule")):blocked=true;return
	marks=parsed.marks;schedule=parsed.get("schedule",{})
	for id in schedule:
		if marks.has(id):schedule[id].due_at=minf(schedule[id].due_at,schedule[id].reviewed_at+Schedule.INTERVALS[marks[id]])
func save_marks()->bool:
	if blocked:return false
	var f:=FileAccess.open(path+".tmp",FileAccess.WRITE)
	if not f:return false
	f.store_string(JSON.stringify({"version":2,"marks":marks,"schedule":schedule}));f.flush();var ok:=f.get_error()==OK;f.close()
	if not ok:return false
	if FileAccess.file_exists(path):
		if FileAccess.file_exists(path+".bak"):DirAccess.remove_absolute(path+".bak")
		if DirAccess.rename_absolute(path,path+".bak")!=OK:return false
	if DirAccess.rename_absolute(path+".tmp",path)==OK:return true
	if FileAccess.file_exists(path+".bak"):DirAccess.rename_absolute(path+".bak",path)
	return false

func arrange()->void:
	if not russian:return
	menu.position=Vector2(size.x*.5-180,size.y*.38);menu.size=Vector2(360,150)
	card.position=Vector2.ZERO;card.size=size
	counter.position=Vector2(40,108);filter.position=Vector2(size.x-250,108)
	var width:float=minf(size.x-160,maxf(320,russian.get_theme_font("font").get_string_size(russian.full_text,HORIZONTAL_ALIGNMENT_LEFT,-1,48).x+24))
	russian.position=Vector2((size.x-width)*.5,size.y*.34);russian.size=Vector2(width,100)
	chinese.position=Vector2(80,size.y*.49);chinese.size=Vector2(size.x-160,90);chinese.add_theme_font_size_override("font_size",26);chinese.modulate=Color("b7dcc6")
	reveal_button.visible=not revealed and not entries.is_empty();reveal_button.position=Vector2(size.x*.5-140,size.y*.74);reveal_button.size=Vector2(280,52)
	grades.visible=revealed and not entries.is_empty();grades.position=Vector2(size.x*.5-340,size.y*.78);grades.size=Vector2(680,52)
	previous.position=Vector2(40,size.y-65);next_button.position=Vector2(size.x-190,size.y-65)
	notice.position=Vector2(80,size.y*.62);notice.size=Vector2(size.x-160,80)
	continue_button.position=Vector2(size.x*.5-100,size.y*.77);continue_button.size=Vector2(200,48)
