if "validate_solved_collision" in globals() and bpy.app.timers.is_registered(validate_solved_collision):bpy.app.timers.unregister(validate_solved_collision)
def validate_solved_collision():
 if stage!='complete':return 2.0
 from mathutils.bvhtree import BVHTree
 output={'source_sha256':ASSET_HASH,'cell_m':93/RES,'checks':[],'cases':{},'method':'BVH ray parity for inside/outside, then exact triangle distance; includes submerged surface vertices. Reconstruction tolerance one FLIP cell.'}
 for case in ['low','high','flare']:
  trees=[]
  for path in sorted((OUT/case).glob('*-collider.json')):
   d=json.loads(path.read_text());trees.append(BVHTree.FromPolygons(d['vertices'],d['faces'],all_triangles=True))
  entries=[]
  for frame in [1,35,55,75,95,110]:
   b=(OUT/case/f'{frame:04}.bwf').read_bytes();nv,ni=struct.unpack_from('<II',b,4)
   v=np.frombuffer(b,dtype='<f4',count=nv*3,offset=12).reshape(-1,3)
   q=v[(v[:,0]>42)&(v[:,0]<110)]
   penetrations=[]
   for xyz in q:
    point=Vector(xyz);depths=[]
    for tree in trees:
     near,normal,index,distance=tree.find_nearest(point)
     if normal.dot(point-near)<-0.00001:
      direction=Vector((.913,.271,.305)).normalized();origin=point.copy();hits=0
      for _ in range(32):
       location,norm,face,dist=tree.ray_cast(origin,direction,300.)
       if location is None:break
       hits+=1;origin=location+direction*.0001
      if hits%2:depths.append(distance)
    if depths:penetrations.append(max(depths))
   max_depth=max(penetrations,default=0.)
   entries.append({'frame':frame,'samples':len(q),'inside_surface_band':len(penetrations),'max_penetration_m':max_depth,'beyond_one_cell':sum(x>93/RES for x in penetrations)})
   output['checks'].append({'name':f'{case} frame {frame} exact BVH collision distance','passed':max_depth<=93/RES})
  output['cases'][case]=entries
 (ROOT/'qa/bow-fluid-exact-collision.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
 return None
bpy.app.timers.register(validate_solved_collision,first_interval=2.)
