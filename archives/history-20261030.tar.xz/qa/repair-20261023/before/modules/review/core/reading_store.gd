extends "res://modules/review/core/safe_store.gd"
func _init()->void:
	path="user://review/reading-review.json"
	data={"schema_version":1,"selected":"Q01","filter":"all","marks":{},"expanded":{},"unknown_words":{},"word_levels":{}}
func valid_id(id:Variant)->bool:
	if not id is String:return false
	for q in JSON.parse_string(FileAccess.get_file_as_string("res://modules/review/content/question_bank.json")):
		if q.id==id:return true
	return false
func read_file()->void:
	if not FileAccess.file_exists(path):return
	var parser:=JSON.new()
	if parser.parse(FileAccess.get_file_as_string(path))!=OK:blocked=true;return
	var value:Variant=parser.data
	if not value is Dictionary or value.get("schema_version")!=1 or not valid_id(value.get("selected")) or value.get("filter") not in ["all","pending"] or not value.get("marks") is Dictionary:blocked=true;return
	for id in value.marks:
		if not valid_id(id) or value.marks[id] not in ["known","review"]:blocked=true;return
	if not value.get("expanded",{}) is Dictionary:blocked=true;return
	if not value.get("unknown_words",{}) is Dictionary:blocked=true;return
	for k in value.get("unknown_words",{}):
		if not k is String or value.unknown_words[k]!=true:blocked=true;return
	if not value.get("word_levels",{}) is Dictionary:blocked=true;return
	for k in value.get("word_levels",{}):
		if not k is String or value.word_levels[k] not in [1,2,3,4]:blocked=true;return
	data=value
	if not data.has("word_levels"):data.word_levels={}
	if not data.has("unknown_words"):data.unknown_words={}
	if not data.has("expanded"):data.expanded={}
