extends Node3D
# Frames are FLIP liquid surfaces baked against the evaluated Blender ship solids.
# Godot replays the solved geometry; it does not claim a live CFD solver.
const ROOT="res://modules/review/assets/bow_fluid/"
var presentation:Control
var surface:MeshInstance3D
var clock:=0.0
var phase:=""
var case_id:=""
var strength:=0.0
var structure_changing:=false
var frame_index:=-1
var mesh_cache:Dictionary={}
var manifests:Dictionary={}
var fps:=24.0
var total_frames:=110
var cache_error:=""
var active_root:=ROOT+"1a8be934/"
var source_hash:=""
func _ready()->void:
 surface=MeshInstance3D.new();add_child(surface)
 var mat:=ShaderMaterial.new();mat.shader=preload("res://modules/review/view/baked_water.gdshader")
 mat.set_shader_parameter("ripple_normal",load("res://assets/ocean/ripple_normal.png"))
 surface.material_override=mat;surface.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
func configure(s:Dictionary)->void:
 if FileAccess.file_exists("res://qa/bow-fluid-paused.json") and not ("--qa" in OS.get_cmdline_user_args() and "--bow-waves" in OS.get_cmdline_user_args()):
  cache_error="Liquid simulation paused pending repaired collision hull";hide();return
 cache_error=""
 var next_phase:String=s.get("phase","")
 var fc:float=float(s.get("forecastle",0))
 structure_changing=fc>.001 and fc<.999
 var next_case:="flare" if next_phase=="flare" else ("high" if float(s.get("forecastle",0))>.01 else "low")
 if phase!=next_phase or next_case!=case_id:
  phase=next_phase;case_id=next_case;clock=0;frame_index=-1;mesh_cache.clear()
 strength=float(s.get("wave",0))
 visible=s.get("topic","")=="freeboard" and phase in ["bow_waves","flare"] and strength>0
 if visible:
  if not manifests.has(case_id):
   var path:=active_root+case_id+"/manifest.json"
   if FileAccess.file_exists(path):manifests[case_id]=JSON.parse_string(FileAccess.get_file_as_string(path))
   else:cache_error="Missing baked liquid case: "+case_id;hide();return
  var m:Dictionary=manifests[case_id]
  if source_hash.is_empty():source_hash=FileAccess.get_sha256("res://modules/review/assets/module11_ship.glb")
  if m.get("source_sha256","")!=source_hash:
   cache_error="Liquid cache does not match current ship geometry";hide();return
  total_frames=int(m.frames);fps=float(m.fps)
  update_frame()
func _process(dt:float)->void:
 if not is_visible_in_tree() or not is_instance_valid(presentation) or not presentation.is_visible_in_tree():return
 if structure_changing:return
 clock+=dt;update_frame()
func packed_vectors(bytes:PackedByteArray,count:int,type:int)->Variant:
 var encoded:=PackedByteArray();encoded.resize(8);encoded.encode_u32(0,type);encoded.encode_u32(4,count);encoded.append_array(bytes)
 return bytes_to_var(encoded)
func load_frame(index:int)->ArrayMesh:
 if mesh_cache.has(index):return mesh_cache[index]
 var path:=active_root+case_id+"/render/%04d.bwf"%index
 var f:=FileAccess.open(path,FileAccess.READ)
 if not f:cache_error="Missing liquid frame "+path;return null
 if f.get_buffer(4).get_string_from_ascii()!="BWF1":cache_error="Invalid liquid frame "+path;return null
 var nv:=f.get_32();var ni:=f.get_32()
 var arrays:=[];arrays.resize(Mesh.ARRAY_MAX)
 arrays[Mesh.ARRAY_VERTEX]=packed_vectors(f.get_buffer(nv*12),nv,TYPE_PACKED_VECTOR3_ARRAY)
 arrays[Mesh.ARRAY_NORMAL]=packed_vectors(f.get_buffer(nv*12),nv,TYPE_PACKED_VECTOR3_ARRAY)
 arrays[Mesh.ARRAY_INDEX]=packed_vectors(f.get_buffer(ni*4),ni,TYPE_PACKED_INT32_ARRAY)
 var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
 mesh_cache[index]=mesh
 if mesh_cache.size()>8:mesh_cache.erase(mesh_cache.keys()[0])
 return mesh
func update_frame()->void:
 if not surface or not visible or not manifests.has(case_id):return
 if structure_changing:
  clock=0.0;surface.hide();return
 surface.show()
 var duration:=float(total_frames-1)/fps
 var t:=fmod(clock,duration+1.0)
 var frame:=clampi(int(minf(t,duration)*fps)+1,1,total_frames)
 if frame!=frame_index:
  var mesh:=load_frame(frame)
  if mesh:surface.mesh=mesh;frame_index=frame
 var fade:=minf(smoothstep(0.0,.3,t),1.0-smoothstep(duration-.4,duration+.1,t))
 surface.material_override.set_shader_parameter("opacity",fade)
 surface.material_override.set_shader_parameter("clock",clock)
